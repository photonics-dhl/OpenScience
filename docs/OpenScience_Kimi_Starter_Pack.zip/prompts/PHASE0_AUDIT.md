# Phase 0 Prompt — Existing Code Audit

先完整阅读 `AGENTS.md`、`docs/PROJECT_SPEC.md` 和 `.agents/skills/repo-map/SKILL.md`。

当前目标不是立即重构，而是完成只读审计。

请：

1. 建立目录、依赖、服务、数据库、环境变量、部署和测试地图；
2. 找出 Hermes、AI Workshop、认证、上传、社区、WebSocket、模型路由和管理员功能；
3. 实际检查入口和调用链，不要依据文件名假设功能可用；
4. 按“保留 / 局部重构 / 替换 / 待确认”分类；
5. 标记安全风险、重复实现、失效功能和数据迁移风险；
6. 不修改业务代码；
7. 输出 `docs/CODEBASE_AUDIT.md`；
8. 输出 `docs/adr/0001-target-architecture.md` 草案；
9. 所有结论引用具体路径或运行证据；
10. 最后列出进入 Phase 1A 前必须由用户确认的问题。

