# Phase 1A Prompt — Platform Foundation

前置条件：Phase 0 审计和 ADR-0001 已由用户确认。

依据 `docs/PROJECT_SPEC.md`，实现最小平台底座：

1. Invitation、邮箱验证、User、Workspace、Membership 和 RBAC；
2. PostgreSQL migration、Redis、Storage Adapter；
3. 统一配置、错误、日志、审计和限流；
4. Docker 化单 ECS 部署；
5. 数据网络与 Sandbox 网络隔离骨架；
6. CI/CD、健康检查、备份和回滚脚本；
7. 最小 Dashboard 壳层和中英文 i18n；
8. 单元、集成与最小 E2E。

约束：

- 保留审计确认可复用的现有功能；
- 不实现第二阶段社区功能；
- 不运行任意 Python；
- 不连接生产实名认证；
- 不部署生产，除非用户另行明确授权。

完成标准：

- 测试通过；
- 权限负例通过；
- 容器健康；
- 数据库不暴露公网；
- 文档和 ADR 更新；
- 输出变更清单、验证证据、回滚方法和剩余风险。

