# OpenScience Agent Instructions

## Mission

Build OpenScience according to `docs/PROJECT_SPEC.md` while preserving useful existing code and user data.

## Mandatory workflow

1. Read `docs/PROJECT_SPEC.md` before planning or editing.
2. For an unfamiliar area, use the read-only `codebase-explorer` or `repo-map` Skill first.
3. State the intended files, migration impact, tests and rollback before a material change.
4. Keep domain logic out of UI components and provider SDKs out of business modules.
5. Every API write must enforce server-side authorization and produce an audit record where required.
6. Treat AI output, uploaded files and generated Python as untrusted input.
7. Never run generated scientific Python in the Web/API process or with database credentials.
8. Never modify an immutable published version.
9. Never duplicate an unchanged blob across versions.
10. Write an ADR for changes to auth, storage, versioning, AI routing, sandboxing, identifiers or deployment topology.

## Verification

- Run the smallest relevant test set after each change.
- Before declaring a phase complete, run unit, integration and relevant E2E tests.
- Report commands executed, results, residual risk and files changed.
- Do not hide failing tests or weaken tests merely to make them pass.

## Safety

- Do not commit secrets, production data, tokens, backups or identity documents.
- No destructive production database operations without explicit approval and a verified backup.
- No direct production deploy unless the user requests it and the deployment checklist passes.
- Use least privilege for MCP, agents, database roles and cloud credentials.

