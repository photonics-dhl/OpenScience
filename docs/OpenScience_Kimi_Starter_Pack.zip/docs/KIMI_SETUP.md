# Kimi Code Setup

## 1. Project files

Keep these files in the repository:

- `AGENTS.md`
- `.kimi-code/agents/`
- `.agents/skills/`
- `.kimi-code/mcp.json`
- `hooks/`

Kimi Code scans project Skills from `.kimi-code/skills/` and `.agents/skills/`, and project Agents from `.kimi-code/agents/` and `.agents/agents/`.

## 2. MCP

Copy `.kimi-code/mcp.example.json` to `.kimi-code/mcp.json`, then enable only the servers needed for the current task.

Recommendations:

- Context7 may remain enabled for current library documentation.
- Keep GitHub disabled until a least-privilege token is configured.
- Keep Playwright disabled until the test origin and browser environment are ready.
- Never configure a production database or unrestricted SSH MCP.
- Prefer `enabledTools` when a server exposes many tools.

Verify with `/mcp`. Configure interactively with `/mcp-config`.

## 3. Permission rules

User-level `~/.kimi-code/config.toml` should keep manual approval as the default. Example:

```toml
default_permission_mode = "manual"
default_plan_mode = false
merge_all_available_skills = true

[[permission.rules]]
decision = "allow"
pattern = "Read"

[[permission.rules]]
decision = "allow"
pattern = "Grep"

[[permission.rules]]
decision = "deny"
pattern = "Bash(rm -rf*)"

[[permission.rules]]
decision = "ask"
pattern = "Bash"
```

Do not use global YOLO mode for this project.

## 4. Hook

The included hook is only defense in depth. Add to user-level `config.toml` after resolving the absolute path:

```toml
[[hooks]]
event = "PreToolUse"
matcher = "Bash"
command = "node /absolute/path/to/hooks/check-dangerous-bash.mjs"
timeout = 5
```

Kimi Hooks fail open on errors/timeouts; high-risk operations still require permission rules and human confirmation.

## 5. Goals

Use `/goal` only with a verifiable finish line. Example:

```text
/goal Complete the Phase 0 audit, create docs/CODEBASE_AUDIT.md and an ADR draft, make no business-code changes, and support every conclusion with file or command evidence.
```

## 6. Windows and macOS

- Keep repository configuration project-relative.
- Do not commit `.kimi-code/local.toml`, because it may contain machine-specific absolute paths.
- Use Node and package-manager versions pinned in the repository.
- Avoid shell scripts that only work in one platform unless they run exclusively on the Linux server.
- Server deployment scripts are authoritative; local Windows/macOS tasks are lightweight preparation and review.

