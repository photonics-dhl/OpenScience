# ADR-0000: Confirmed Product and Architecture Decisions

- Status: Accepted
- Date: 2026-07-24

## Decision

Use `docs/PROJECT_SPEC.md` sections 2 and 22 as the baseline for the invitation-beta architecture and delivery sequence.

## Consequences

- Existing code must be audited before refactoring.
- The MVP is centered on SDF publication and Git-like scientific collaboration.
- Published versions are immutable and use content-addressed incremental storage.
- The invitation beta may use one ECS, but generated Python is isolated and must move to a separate execution node before public-scale operation.
- Hermes is the unified main Agent with constrained sub-agents/workers.
- Community expansion, editable graphs and publication infrastructure are Phase 2.

