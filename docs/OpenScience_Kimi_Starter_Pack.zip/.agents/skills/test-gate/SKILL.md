---
name: test-gate
description: Verify an OpenScience feature or milestone against requirements and report evidence before completion is claimed
type: flow
whenToUse: Before declaring a task, pull request, release or phase complete
disableModelInvocation: true
arguments:
  - target
---

For `$target`:

1. Map requirements to tests.
2. Run the smallest relevant deterministic checks.
3. Run integration/E2E checks for changed boundaries.
4. Include authorization-negative cases.
5. Verify responsive behavior for affected UI.
6. Report exact commands, pass/fail results and artifacts.
7. List anything not tested and why.

Do not weaken tests or convert failures into snapshots merely to pass the gate.

