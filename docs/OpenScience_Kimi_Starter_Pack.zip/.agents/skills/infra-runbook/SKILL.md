---
name: infra-runbook
description: Plan, deploy and verify OpenScience infrastructure with scripted rollback, backup and sandbox network isolation
type: flow
whenToUse: Server setup, Docker, CI/CD, release, backup, restore or production operations
disableModelInvocation: true
arguments:
  - operation
---

For `$operation`:

1. Resolve the exact environment and target.
2. Check backups, health, capacity, secrets and rollback.
3. Show the commands and expected impact before a write.
4. Keep database and Redis private.
5. Keep generated-code containers off the data network and free of credentials.
6. Deploy with health checks and a reversible release identifier.
7. Verify externally visible behavior and internal metrics.
8. Record the outcome in the runbook.

Never perform a production deploy or destructive operation without explicit authorization.

