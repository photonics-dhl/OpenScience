---
name: frontend-design
description: Build coherent responsive OpenScience interfaces with mobile parity, accessibility and clear Agent approvals
type: prompt
whenToUse: Designing or implementing pages, components, editor layouts or user flows
disableModelInvocation: false
arguments:
  - surface
---

Design `$surface` with:

- modern workspace styling for authenticated tools;
- academic publishing styling for public Research Objects;
- GitHub-like collaboration patterns for diff, Issue, PR and Review;
- Chinese-first copy with i18n keys and English support;
- complete desktop/mobile capabilities using adaptive layout;
- loading, empty, error, retry and offline/local-only states;
- keyboard access and semantic HTML;
- batched Agent previews with risk level, scope, reversibility, cost and duration.

Do not hide unfinished behavior behind decorative UI.

