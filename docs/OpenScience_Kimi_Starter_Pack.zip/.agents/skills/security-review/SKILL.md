---
name: security-review
description: Threat-model and review OpenScience changes involving auth, uploads, AI tools, publishing, storage or Python execution
type: flow
whenToUse: Security-sensitive implementation or release review
disableModelInvocation: true
arguments:
  - target
---

Review `$target` for:

- IDOR and cross-Workspace access;
- privilege escalation and confused deputy behavior;
- secret, identity and manuscript leakage;
- unsafe upload parsing;
- SSRF and cloud metadata access;
- prompt injection causing tool use;
- sandbox escape and resource exhaustion;
- audit-log integrity;
- insecure dependency or default configuration.

Return severity-ranked findings with evidence, attack path, impact, remediation and a verification test. Hooks and AI review are defense in depth, not the only barrier.

