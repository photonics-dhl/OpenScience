---
name: database-migration
description: Plan and verify safe PostgreSQL schema changes for OpenScience without losing or silently rewriting user data
type: flow
whenToUse: Any schema, index, constraint, identifier or content-addressed storage migration
disableModelInvocation: true
arguments:
  - migration
---

For `$migration`:

1. Inspect current schema and real access paths.
2. State invariants and compatibility window.
3. Prefer expand → backfill → switch → contract.
4. Estimate lock, table-scan and index-build impact.
5. Provide rollback or compensating action.
6. Add migration and reconstruction tests.
7. Verify immutable versions, unique identifiers and Workspace ownership.
8. Never execute against production without explicit approval and verified backup.

