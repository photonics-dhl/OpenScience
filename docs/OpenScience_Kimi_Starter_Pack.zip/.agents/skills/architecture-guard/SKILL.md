---
name: architecture-guard
description: Check proposed OpenScience changes against module boundaries, migration strategy and recorded architecture decisions
type: prompt
whenToUse: Planning or reviewing a cross-module change, service split or major refactor
disableModelInvocation: false
arguments:
  - change
---

Evaluate `$change` against `docs/PROJECT_SPEC.md` and existing ADRs.

Require:

- an incremental path from the current code;
- explicit ownership of data and invariants;
- no unnecessary microservices for the invitation beta;
- provider adapters for AI and object storage;
- a future path from single ECS to managed data services and isolated sandbox execution;
- compatibility, rollback and observability;
- an ADR for a consequential decision.

Report violations before implementation.

