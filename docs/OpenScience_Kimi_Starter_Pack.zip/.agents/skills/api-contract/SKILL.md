---
name: api-contract
description: Design or review OpenScience API contracts with authorization, idempotency, validation and failure semantics
type: prompt
whenToUse: Creating or changing HTTP endpoints, events or asynchronous task APIs
disableModelInvocation: false
arguments:
  - resource
---

For `$resource`, define or verify:

1. Request and response schema.
2. Authentication and resource-level authorization.
3. Idempotency and optimistic concurrency.
4. Validation and stable error codes.
5. Audit events.
6. Pagination, filtering and rate limits.
7. Async progress and retry behavior where applicable.
8. Unit, integration and contract tests.

Never trust front-end role checks as authorization.

