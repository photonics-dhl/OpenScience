---
name: repo-map
description: Produce an evidence-backed map of the existing OpenScience repository before modifying unfamiliar code
type: flow
whenToUse: Initial audit or before changing an unfamiliar subsystem
disableModelInvocation: true
arguments:
  - scope
---

Map `$scope` without modifying business code.

1. Read `AGENTS.md` and `docs/PROJECT_SPEC.md`.
2. List entry points, packages, services, database layers, queues, storage, external APIs and deployment files.
3. Locate tests and run only harmless inspection commands.
4. Classify relevant code as keep, refactor, replace or unknown.
5. Record concrete file-path evidence.
6. Identify data-migration and security risks.
7. Save the report only when the user asked for an artifact.

Do not infer runtime behavior from filenames alone.

