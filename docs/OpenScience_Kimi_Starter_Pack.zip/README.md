# OpenScience Kimi Code Starter

本目录用于在现有 OpenScience/Scholars Tea 仓库中启动重构工作。

## 使用顺序

1. 将本目录内容合并到项目根目录，保留现有代码。
2. 先阅读 `docs/PROJECT_SPEC.md`。
3. 检查 `.kimi-code/mcp.example.json`，复制为 `.kimi-code/mcp.json` 前替换环境变量并删除不需要的 MCP。
4. 审查 `.kimi-code/agents/` 和 `.agents/skills/` 中的权限。
5. 使用 `prompts/PHASE0_AUDIT.md` 启动只读审计。
6. 未完成审计和 ADR 审批前，不进入大规模重构。

`PROJECT_SPEC.md` 是 AI 使用的主规格；同名 DOCX 是供人类审阅的版本。

