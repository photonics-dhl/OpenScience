let input = "";

process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  input += chunk;
});

process.stdin.on("end", () => {
  let payload;
  try {
    payload = JSON.parse(input);
  } catch {
    process.exit(0);
  }

  const command = String(payload.tool_input?.command ?? "");
  const blocked = [
    /\brm\s+-rf\s+(\/|~|\$HOME|\$\{HOME\})/i,
    /\bgit\s+reset\s+--hard\b/i,
    /\bgit\s+clean\s+-[a-z]*f/i,
    /\bdocker\s+system\s+prune\b/i,
    /\bDROP\s+(DATABASE|SCHEMA)\b/i,
    /\bTRUNCATE\s+TABLE\b/i,
    /\bmkfs(\.|\s)/i,
    /\bdd\s+if=.*\s+of=\/dev\//i
  ];

  if (blocked.some((pattern) => pattern.test(command))) {
    console.error("Blocked a potentially destructive command. Resolve the exact target and request explicit approval.");
    process.exit(2);
  }

  process.exit(0);
});

